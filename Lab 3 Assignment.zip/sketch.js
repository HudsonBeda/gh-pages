function setup() {
  createCanvas(720, 400);
  background(120)
  frameRate (30)
  color(255,0,255)
  rectx =+ 1 
var y = 60;
var d = 80;
}
var x;
x = 12
var x = 12
function draw() {
  colorMode(RGB, 255,255,255,1);
  fill(255,0,255)
  noStroke();
  stroke(0,200)
  color(255,0,255)
  ellipse(mouseX, mouseY, 9, 9);
  abs(20)
  print(20);
  print(30);
  frameRate(30)
  line(mouseX, movedY, pmouseX, pmouseY)
  colorMode(RGB, 255,255,255,1);
  fill(200,0,200);
  
  line(180, 180, 180 + 180, 180);
  line(180, 180 + 10, 180 + 180, 180 + 10);
  line(180, 180 + 20, 180 + 180, 180 + 20);
  line(180, 180 + 30, 180 + 180, 180 + 30);
  
    line(300, 300, 300 + 200, 300);
  line(300, 300 + 10, 300 + 200, 300 + 10);
  line(300, 300 + 20, 300 + 200, 300 + 20);
  line(300, 300 + 30, 300 + 200, 300 + 30);
  
   line(350, 350, 250 + 200, 350);
  line(350, 350 + 10, 250 + 200, 350 + 10);
  line(350, 350 + 20, 250 + 200, 350 + 20);
  line(350, 350 + 30, 250 + 200, 350 + 30);
}
