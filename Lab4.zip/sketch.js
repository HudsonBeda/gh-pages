function setup() {
  createCanvas(400, 400);
  background(220)
}
function draw() {
  if (keyIsPressed) 
    if ((key == 'h') || (key == 'H')) 
      line(30,60,90,60);
    }
// Click within the image to change
// the value of the rectangle
// after the mouse has been clicked
let value = 25;
function draw() {
  fill(value);
  rect(25, 25, 50, 50);
  describe('black 50-by-50 rect turns white with mouse click/press.');
}
function mouseClicked() {
  if (value === 0) {
    value = 255;
  } else {
    value = 0;
  }
}
// This example logs the lines below to the console
// 4
// 3
// 2
// 1
// 0
let num = 4;
while (num > 0) {
  num = num - 1;
  console.log(num);
}