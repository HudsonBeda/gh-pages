function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(120);
  fill(255)
  rect(20,20,300);
  fill(0)
  rect(330,325,50);
  circle(290,350,50);
  line(mouseX, 0, mouseX, 400);
  line(0, mouseY, 400, mouseY);
  function draw() {
  if (keyIsPressed === true) {
    fill(0);
  } else {
    fill(255);
  }
  rect(5, 5, 5, 5);
}
}
function mouseClicked() {
  if (blue === 0) {
    value = 255;
  } else {
    value = 0;
  }
}
